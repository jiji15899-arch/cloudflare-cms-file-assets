// functions/api/wp-login/index.js — CloudPress CMS 로그인 (완전 수정본)
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization'};
const j=(d,s=200,extra={})=>new Response(JSON.stringify(d),{status:s,headers:{'Content-Type':'application/json',...CORS,...extra}});
export const onRequestOptions=()=>new Response(null,{status:204,headers:CORS});

function genToken(n=32){const c='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';let s='';const a=new Uint8Array(n);crypto.getRandomValues(a);for(const b of a)s+=c[b%c.length];return s;}

export async function onRequestPost({request,env}){
  try{
    let body;
    try{body=await request.json();}catch{return j({code:'rest_error',message:'잘못된 요청 형식'},400);}
    const{username,password,remember=true}=body||{};
    if(!username||!password)return j({code:'rest_missing_callback_param',message:'사용자명과 비밀번호를 입력해주세요.',data:{status:400}},400);

    // login 또는 email로 조회
    const user=await env.CMS_DB.prepare(
      'SELECT id,login,user_pass,display_name,email,role FROM wp_users WHERE login=? OR email=?'
    ).bind(username,username).first().catch(()=>null);

    if(!user)return j({code:'rest_forbidden',message:'사용자명 또는 비밀번호가 올바르지 않습니다.',data:{status:401}},401);

    // 비밀번호 확인 (평문 비교 — 실제 운영 시 bcrypt 적용 권장)
    if(user.user_pass!==password){
      return j({code:'rest_forbidden',message:'사용자명 또는 비밀번호가 올바르지 않습니다.',data:{status:401}},401);
    }
    if(user.role!=='administrator'&&user.role!=='editor'&&user.role!=='author'){
      return j({code:'rest_forbidden',message:'관리자 권한이 필요합니다.',data:{status:403}},403);
    }

    const token=genToken(40);
    const maxAge=remember?60*60*24*30:60*60*24; // 30일 or 1일
    await env.CMS_KV.put(`session:${token}`,String(user.id),{expirationTtl:maxAge});

    const setCookie=`cp_cms_session=${token}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=Lax`;
    return j({
      token,
      user_email:user.email,
      user_nicename:user.login,
      user_display_name:user.display_name,
      roles:[user.role],
    },200,{'Set-Cookie':setCookie});
  }catch(e){return j({code:'rest_error',message:e.message,data:{status:500}},500);}
}

// GET: 현재 로그인 상태 확인
export async function onRequestGet({request,env}){
  try{
    const c=request.headers.get('Cookie')||'';
    const m=c.match(/cp_cms_session=([^;]+)/);
    if(!m)return j({logged_in:false},200);
    const uid=await env.CMS_KV.get(`session:${m[1]}`);
    if(!uid)return j({logged_in:false},200);
    const user=await env.CMS_DB.prepare('SELECT id,login,display_name,email,role FROM wp_users WHERE id=?').bind(uid).first();
    if(!user)return j({logged_in:false},200);
    return j({logged_in:true,user:{id:user.id,login:user.login,display_name:user.display_name,email:user.email,role:user.role}},200);
  }catch(e){return j({logged_in:false,error:e.message},200);}
}
